from .browser import Browser
from .functions import get_available_browser
from .pages import Page